-- STARBOY order table setup
-- Run this script in Supabase Dashboard > SQL Editor.
-- The storefront uses the anon/public key only. Do not put a service_role key in script.js.

create extension if not exists pgcrypto;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  customer_name text not null,
  customer_phone text not null,
  shipping_address text not null,
  notes text,
  items jsonb not null,
  total_amount integer not null check (total_amount >= 0),
  status text not null default 'pending'
    check (status in ('pending', 'confirmed', 'processing', 'shipped', 'completed', 'cancelled'))
);

alter table public.orders enable row level security;

-- Customers can submit an order from the public storefront.
-- Public visitors cannot read, update, or delete orders.
drop policy if exists "Public can create orders" on public.orders;
create policy "Public can create orders"
on public.orders
for insert
to anon, authenticated
with check (
  char_length(customer_name) between 1 and 120
  and char_length(customer_phone) between 6 and 30
  and char_length(shipping_address) between 5 and 1000
  and jsonb_typeof(items) = 'array'
);

-- No SELECT policy is intentionally provided. Manage/read orders in the
-- Supabase dashboard or from a trusted server-side admin environment.
