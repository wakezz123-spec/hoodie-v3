// STARBOY storefront. Orders are sent directly to WhatsApp.
const WHATSAPP_NUMBER = "6285135751969"; // 0851-3575-1969
// Optional: fill these in after creating a Supabase project. Never put a service_role key here.
const SUPABASE_URL = "";
const SUPABASE_ANON_KEY = "";

const products = [
  {id:1,name:"MIDNIGHT ESSENTIAL",type:"BLACK / OVERSIZED FIT",price:249000,tag:"BEST SELLER",image:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=700&q=85"},
  {id:2,name:"ASH GREY CLUB",type:"GREY / DAILY UNIFORM",price:259000,tag:"NEW DROP",image:"https://images.unsplash.com/photo-1578681994506-b8f0f846a9e8?auto=format&fit=crop&w=700&q=85"},
  {id:3,name:"AFTER HOURS",type:"DARK CHARCOAL / RELAXED",price:269000,tag:"LIMITED",image:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=700&q=85"},
  {id:4,name:"OFF DUTY",type:"STONE / OVERSIZED FIT",price:249000,tag:"EVERYDAY",image:"https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=700&q=85"}
];
let cart = JSON.parse(localStorage.getItem("starboy-cart") || "[]");
const money = n => new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);
const grid = document.getElementById("productGrid");

function renderProducts(){
  grid.innerHTML = products.map(p=>`<article class="product-card">
    <div class="product-image-wrap"><img class="product-image" src="${p.image}" alt="${p.name}" loading="lazy"><span class="product-tag">${p.tag}</span>
    <button class="quick-add" data-add="${p.id}">ADD TO BAG +</button></div>
    <div class="product-info"><div><h3>${p.name}</h3><p>${p.type}</p></div><span class="price">${money(p.price)}</span></div>
  </article>`).join("");
}
function saveCart(){localStorage.setItem("starboy-cart",JSON.stringify(cart));renderCart();}
function addToCart(id){const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id,qty:1});saveCart();openCart();}
function renderCart(){
  const count=cart.reduce((s,x)=>s+x.qty,0),total=cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0);
  document.getElementById("cartCount").textContent=count;document.getElementById("drawerCount").textContent=`(${count})`;document.getElementById("cartTotal").textContent=money(total);
  document.getElementById("cartItems").innerHTML=cart.length?cart.map(x=>{const p=products.find(z=>z.id===x.id);return `<div class="cart-item"><img src="${p.image}" alt=""><div><h3>${p.name}</h3><p>${money(p.price)}</p><div class="qty-controls"><button data-qty="${p.id}" data-delta="-1">−</button><span>${x.qty}</span><button data-qty="${p.id}" data-delta="1">+</button></div></div><button class="remove-item" data-remove="${p.id}" aria-label="Hapus">✕</button></div>`}).join(""):'<p class="empty-cart">Your bag is currently empty.</p>';
  document.getElementById("checkoutButton").disabled=!cart.length;
}
function openCart(){document.getElementById("cartDrawer").classList.add("open");document.getElementById("cartOverlay").classList.add("open");document.body.classList.add("no-scroll");document.getElementById("cartDrawer").setAttribute("aria-hidden","false");}
function closeCart(){document.getElementById("cartDrawer").classList.remove("open");document.getElementById("cartOverlay").classList.remove("open");document.body.classList.remove("no-scroll");document.getElementById("cartDrawer").setAttribute("aria-hidden","true");}
function orderText(data){
  const lines=cart.map(x=>{const p=products.find(z=>z.id===x.id);return `• ${p.name} x${x.qty} — ${money(p.price*x.qty)}`;});
  const total=cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0);
  return `HALO STARBOY! Saya ingin memesan hoodie:\\n\\n${lines.join("\\n")}\\n\\nSubtotal: ${money(total)}\\n\\nNama: ${data.name}\\nNo. WA: ${data.phone}\\nAlamat: ${data.address}\\nCatatan: ${data.note||"-"}\\n\\nMohon konfirmasi stok, ukuran, dan ongkir. Terima kasih!`;
}
async function saveOrderToSupabase(data){
  if(!SUPABASE_URL||!SUPABASE_ANON_KEY)return;
  const total=cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0);
  try{await fetch(`${SUPABASE_URL}/rest/v1/orders`,{method:"POST",headers:{"Content-Type":"application/json","apikey":SUPABASE_ANON_KEY,"Authorization":`Bearer ${SUPABASE_ANON_KEY}`,"Prefer":"return=minimal"},body:JSON.stringify({customer_name:data.name,customer_phone:data.phone,shipping_address:data.address,notes:data.note||null,items:cart.map(x=>({product_id:x.id,product_name:products.find(p=>p.id===x.id).name,quantity:x.qty,unit_price:products.find(p=>p.id===x.id).price})),total_amount:total,status:"pending"})});}catch(e){console.warn("Supabase order save failed:",e);}
}

grid.addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(b)addToCart(Number(b.dataset.add));});
document.getElementById("cartItems").addEventListener("click",e=>{
  const q=e.target.closest("[data-qty]"),r=e.target.closest("[data-remove]");
  if(q){const item=cart.find(x=>x.id===Number(q.dataset.qty));item.qty+=Number(q.dataset.delta);if(item.qty<1)cart=cart.filter(x=>x.id!==item.id);saveCart();}
  if(r){cart=cart.filter(x=>x.id!==Number(r.dataset.remove));saveCart();}
});
document.getElementById("cartButton").addEventListener("click",openCart);
document.getElementById("closeCart").addEventListener("click",closeCart);
document.getElementById("cartOverlay").addEventListener("click",closeCart);
document.getElementById("checkoutButton").addEventListener("click",()=>{
  if(!cart.length)return;
  closeCart();document.getElementById("checkoutSummary").textContent=`${cart.reduce((s,x)=>s+x.qty,0)} item · Subtotal ${money(cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0))}`;
  document.getElementById("checkoutModal").classList.add("open");document.body.classList.add("no-scroll");
});
function closeModal(){document.getElementById("checkoutModal").classList.remove("open");document.body.classList.remove("no-scroll");}
document.getElementById("closeModal").addEventListener("click",closeModal);
document.getElementById("checkoutModal").addEventListener("click",e=>{if(e.target.id==="checkoutModal")closeModal();});
document.getElementById("checkoutForm").addEventListener("submit",async e=>{
  e.preventDefault();if(!cart.length)return;
  const data=Object.fromEntries(new FormData(e.currentTarget).entries());
  const message=orderText(data);
  // Save to Supabase if configured, then open WhatsApp with the same order details.
  await saveOrderToSupabase(data);
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`,"_blank","noopener");
  cart=[];saveCart();e.currentTarget.reset();closeModal();
});
renderProducts();renderCart();
